<?php

/**
* @Project NUKEVIET 4.x
* @Author VINADES.,JSC <contact@vinades.vn>
* @Copyright (C) 2018 VINADES.,JSC. All rights reserved
* @Language Français
* @License CC BY-SA (http://creativecommons.org/licenses/by-sa/4.0/)
* @Createdate Jan 31, 2018, 01:08:00 AM
*/

$lang_block['qr_level'] = 'Qualité des images';
$lang_block['qr_pixel_per_point'] = 'Taille de QR-code ';
$lang_block['qr_outer_frame'] = 'Bord de QR-code';
$lang_block['cominfo_map_yes'] = 'Activez Google MAP';
$lang_block['cominfo_map_no'] = 'Désactivew Google MAP';
$lang_block['cominfo_mapurl'] = 'Google MAP Iframe URL';
