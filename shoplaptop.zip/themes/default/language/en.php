<?php

/**
* @Project NUKEVIET 4.x
* @Author VINADES.,JSC <contact@vinades.vn>
* @Copyright (C) 2018 VINADES.,JSC. All rights reserved
* @Language English
* @License CC BY-SA (http://creativecommons.org/licenses/by-sa/4.0/)
* @Createdate Jan 31, 2018, 01:08:00 AM
*/

$lang_block['qr_level'] = 'QR-code Image quality';
$lang_block['qr_pixel_per_point'] = 'QR-code Image Size ';
$lang_block['qr_outer_frame'] = 'QR-code Image Border';
$lang_block['cominfo_map_yes'] = 'Enable Google MAP';
$lang_block['cominfo_map_no'] = 'Disable Google MAP';
$lang_block['cominfo_mapurl'] = 'Google MAP Iframe URL';
